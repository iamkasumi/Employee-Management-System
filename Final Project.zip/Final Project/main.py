import sys
from login_Window import UI_Login_Window
from system_Window import Ui_SystemWindow
from signup_Window import Ui_SignUp
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMessageBox
import MySQLdb as mdb

class my_app(QtWidgets.QMainWindow):
    # constructor
    def __init__(self):
        super(my_app, self).__init__()
        self.ui_login = UI_Login_Window()
        self.ui_sys = Ui_SystemWindow()
        self.ui_signUp = Ui_SignUp()
        self.login_window()
        self.accID = 0

    # this method is for displaying login page
    def login_window(self):
        self.ui_login.setupUi(self)
        # ------function to open system window when login was clicked--------
        self.ui_login.bttn_login.clicked.connect(self.main_page)
        
        
        # ------function to open signup window when signup was clicked--------
        self.ui_login.bttn_signUp.clicked.connect(self.signUp_ui)

    #method to open the home page
    def main_page(self):
        
        if self.ui_login.line_username.text() != "" and self.ui_login.line_password.text() != "":
            
            if(self.ui_login.selectIfExists()):
                self.employeeHome()
                self.ui_sys.bttn_exit.clicked.connect(self.login_window)
            else:
                QMessageBox.information(None, "Notification", "User doesn't exists in our records! Please sign up first")
                self.signUp_ui()
        else:
            QMessageBox.information(None, "Notification", "Please input all fields!")
        
    # method for displaying employee home
    def employeeHome(self):
        self.ui_sys.setupUi(self)
        self.add_combo()
        self.ui_sys.bttn_save.clicked.connect(self.ui_sys.insertEmpInfo)
        self.ui_sys.bttn_update.clicked.connect(self.ui_sys.updateEmpInfo)
        self.ui_sys.bttn_reset.clicked.connect(self.ui_sys.resetFields)
        self.ui_sys.bttn_delete.clicked.connect(self.ui_sys.deleteEmpInfo)
        self.ui_sys.search_button.clicked.connect(self.ui_sys.search_table)

    # method for displaying signup page
    def signUp_ui(self):
        self.ui_signUp.setupUi(self)
        # ------function to open login window when back button was clicked--------
        self.ui_signUp.bttn_back.clicked.connect(self.login_window)

        # ------connect sign-up button to clicked method--------
        self.ui_signUp.bttn_signup.clicked.connect(self.clicked)
        
    # method for adding options in combo box
    def add_combo(self):
        options = ["Single", "Married", "Separated", "Divorced"]
        for option in options:
            self.ui_sys.cmb_mariStat.addItem(option)
    # method for showing sign up page
    def signed_up(self):
        # Remove the following line since setupUi() is already called in signUp_ui()
        self.ui_signUp.setupUi(self)
        # Remove the previous connection
        self.ui_signUp.bttn_signup.clicked.disconnect()

        # ------connect sign-up button to clicked method--------
        self.ui_signUp.bttn_signup.clicked.connect(self.clicked)

    # method for inserting sign up to database
    def clicked(self):
        username = self.ui_signUp.line_username.text()
        password = self.ui_signUp.line_password.text()

        if username != "" and password != "":
            if(self.ui_signUp.unameExists()):
                QMessageBox.information(None, "Notification", "Username already exists! Please input another")
                self.ui_signUp.line_username.clear()
                self.ui_signUp.line_password.clear()
            else:
                self.ui_signUp.insertnewUser() #this is for inserting signup info to database
                self.login_window()
        else:
            QMessageBox.information(None, "Notification", "Please input all fields!")
            
            

#-----------------------------------------code runner-----------------------------
def run_app():
    app = QtWidgets.QApplication(sys.argv)
    win = my_app()
    win.show()
    sys.exit(app.exec_())

run_app()