-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2023 at 04:27 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jape_solutions_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

CREATE TABLE `tbl_account` (
  `id` int(6) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_account`
--

INSERT INTO `tbl_account` (`id`, `username`, `password`) VALUES
(1, 'halaman', 'hatdog'),
(2, 'pamuname', 'pampass'),
(13, 'pam', 'pass');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_empinfo`
--

CREATE TABLE `tbl_empinfo` (
  `EmpID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(255) NOT NULL,
  `Sex` varchar(255) NOT NULL,
  `MaritalStatus` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Designation` varchar(255) NOT NULL,
  `DateStarted` date NOT NULL,
  `Salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_empinfo`
--

INSERT INTO `tbl_empinfo` (`EmpID`, `Name`, `PhoneNumber`, `Sex`, `MaritalStatus`, `Address`, `DateOfBirth`, `Email`, `Department`, `Designation`, `DateStarted`, `Salary`) VALUES
(21111, 'Pamela Pam', '090000', 'Male', 'Single', 'Bauan', '2002-07-03', 'pam@pam.com', 'CICS', 'IT', '2023-05-22', 5000),
(888888, 'Pamela Villegas', '0988888', 'Female', 'Married', 'address', '2003-05-22', 'pam@pam.com', 'cics', 'it', '2020-05-22', 888888),
(2222222, 'Wawa', '21928192', 'Female', 'Single', 'fdfdfd', '2003-05-22', 'fdfd', 'fdfd', 'fdfdf', '2023-05-22', 23232323);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_account`
--
ALTER TABLE `tbl_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_empinfo`
--
ALTER TABLE `tbl_empinfo`
  ADD PRIMARY KEY (`EmpID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_account`
--
ALTER TABLE `tbl_account`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
