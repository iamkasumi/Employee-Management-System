from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox

import MySQLdb as mdb


class Ui_SignUp(object):
    def setupUi(self, SignUp):
        SignUp.setObjectName("SignUp")
        SignUp.resize(1201, 716)
        self.centralwidget = QtWidgets.QWidget(SignUp)
        self.centralwidget.setObjectName("centralwidget")
        self.bttn_signup = QtWidgets.QPushButton(self.centralwidget)
        self.bttn_signup.setGeometry(QtCore.QRect(560, 480, 231, 51))
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(14)
        font.setBold(False)
        font.setWeight(50)
        self.bttn_signup.setFont(font)
        self.bttn_signup.setStyleSheet("QPushButton {\n"
"    background-color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(215, 242, 255);\n"
"}")
        self.bttn_signup.setObjectName("bttn_signup")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-10, -20, 281, 741))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("UI_Designs\\modern.jpg"))
        self.label_2.setScaledContents(True)
        self.label_2.setObjectName("label_2")
        self.lbl_username = QtWidgets.QLabel(self.centralwidget)
        self.lbl_username.setGeometry(QtCore.QRect(560, 330, 171, 41))
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.lbl_username.setFont(font)
        self.lbl_username.setObjectName("lbl_username")
        self.admin_logo = QtWidgets.QLabel(self.centralwidget)
        self.admin_logo.setGeometry(QtCore.QRect(320, 290, 191, 181))
        font = QtGui.QFont()
        font.setFamily("Stencil")
        font.setPointSize(26)
        font.setBold(False)
        font.setWeight(50)
        font.setKerning(False)
        self.admin_logo.setFont(font)
        self.admin_logo.setAutoFillBackground(False)
        self.admin_logo.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.admin_logo.setFrameShadow(QtWidgets.QFrame.Raised)
        self.admin_logo.setMidLineWidth(0)
        self.admin_logo.setText("")
        self.admin_logo.setPixmap(QtGui.QPixmap("UI_Designs\\admin_logo-removebg-preview.png"))
        self.admin_logo.setScaledContents(True)
        self.admin_logo.setWordWrap(False)
        self.admin_logo.setTextInteractionFlags(QtCore.Qt.LinksAccessibleByMouse)
        self.admin_logo.setObjectName("admin_logo")
        self.line_username = QtWidgets.QLineEdit(self.centralwidget) #for creation of text field of username
        self.line_username.setGeometry(QtCore.QRect(730, 330, 331, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.line_username.setFont(font)
        self.line_username.setObjectName("line_username")
        self.emp_title = QtWidgets.QLabel(self.centralwidget)
        self.emp_title.setGeometry(QtCore.QRect(350, 70, 791, 71))
        font = QtGui.QFont()
        font.setFamily("Bernard MT Condensed")
        font.setPointSize(39)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        self.emp_title.setFont(font)
        self.emp_title.setObjectName("emp_title")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(270, -20, 941, 731))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("UI_Designs\\gray.jpg"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.lbl_admin = QtWidgets.QLabel(self.centralwidget)
        self.lbl_admin.setGeometry(QtCore.QRect(650, 210, 351, 81))
        font = QtGui.QFont()
        font.setFamily("Segoe UI Black")
        font.setPointSize(28)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        font.setKerning(True)
        self.lbl_admin.setFont(font)
        self.lbl_admin.setObjectName("lbl_admin")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(50, 40, 161, 141))
        self.label_3.setText("")
        self.label_3.setPixmap(QtGui.QPixmap("UI_Designs\\JAPE Logo.png"))
        self.label_3.setScaledContents(True)
        self.label_3.setObjectName("label_3")
        self.lbl_password = QtWidgets.QLabel(self.centralwidget)
        self.lbl_password.setGeometry(QtCore.QRect(560, 390, 171, 41))
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.lbl_password.setFont(font)
        self.lbl_password.setObjectName("lbl_password")
        self.line_password = QtWidgets.QLineEdit(self.centralwidget) #txt field for password
        self.line_password.setGeometry(QtCore.QRect(730, 390, 331, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.line_password.setFont(font)
        self.line_password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.line_password.setObjectName("line_password")
        self.bttn_back = QtWidgets.QPushButton(self.centralwidget)
        self.bttn_back.setGeometry(QtCore.QRect(840, 480, 221, 51))
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(14)
        font.setBold(False)
        font.setWeight(50)
        self.bttn_back.setFont(font)
        self.bttn_back.setStyleSheet("QPushButton {\n"
"    background-color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(215, 242, 255);\n"
"}")
        self.bttn_back.setObjectName("bttn_back")
        self.label.raise_()
        self.label_2.raise_()
        self.lbl_username.raise_()
        self.emp_title.raise_()
        self.bttn_signup.raise_()
        self.line_password.raise_()
        self.lbl_admin.raise_()
        self.label_3.raise_()
        self.admin_logo.raise_()
        self.lbl_password.raise_()
        self.line_username.raise_()
        self.bttn_back.raise_()
        SignUp.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(SignUp)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1201, 26))
        self.menubar.setObjectName("menubar")
        SignUp.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(SignUp)
        self.statusbar.setObjectName("statusbar")
        SignUp.setStatusBar(self.statusbar)

        self.retranslateUi(SignUp)
        
        QtCore.QMetaObject.connectSlotsByName(SignUp)

    def retranslateUi(self, SignUp):
        _translate = QtCore.QCoreApplication.translate
        SignUp.setWindowTitle(_translate("SignUp", "Sign-up Window"))
        self.bttn_signup.setText(_translate("SignUp", "Sign-Up"))
        self.lbl_username.setText(_translate("SignUp", "Username:"))
        self.emp_title.setText(_translate("SignUp", "Employee Management System"))
        self.lbl_admin.setText(_translate("SignUp", "Admin Sign-up"))
        self.lbl_password.setText(_translate("SignUp", "Password:"))
        self.bttn_back.setText(_translate("SignUp", "Back"))


    # checks if username already exists
    def unameExists(self):
        try:
            conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
            cur=conn.cursor()
            query = "SELECT * FROM tbl_account WHERE username = %s"  # Update the query
            values = (self.line_username.text(),)  # Set the value to exclude
    
            cur.execute(query, values)
            
            return cur.fetchone() is not None
            conn.close()
        
        except mdb.Error as e:
            QMessageBox.information(None, "Notification", "unameExists sql query failed")
            
            
            
    # for inserting new user to DB
    def insertnewUser(self):
        try:
            conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
            cur=conn.cursor()
            query = "INSERT INTO tbl_account (username, password) VALUES (%s, %s)"
            values = (self.line_username.text(), self.line_password.text())
            cur.execute(query, values)
            conn.commit()
            conn.close()
            
            # clears all field after use
            self.line_username.clear()
            self.line_password.clear()
            QMessageBox.information(None, "Notification", "Account has successfully created!")
            
        
        except mdb.Error as e:
            QMessageBox.information(None, "Notification", "There's an error executing sql statement!")