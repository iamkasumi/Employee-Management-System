from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox, QButtonGroup, QTableWidgetItem, QTableWidget, QVBoxLayout, QWidget, QScrollArea, QLineEdit, QPushButton
from PyQt5.QtCore import QDateTime, Qt

import MySQLdb as mdb

class Ui_SystemWindow(object):
    def __init__(self):
        self.statEmID=0
        self.accID=0
    
    def setupUi(self, SystemWindow):
        SystemWindow.setObjectName("SystemWindow")
        SystemWindow.resize(1531, 800)
    
        self.centralwidget = QtWidgets.QWidget(SystemWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.scrollArea = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea.setGeometry(QtCore.QRect(0, 0, 1531, 921))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        
        self.scrollAreaWidgetContents = QtWidgets.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 1511, 901))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        
        self.label = QtWidgets.QLabel(self.scrollAreaWidgetContents)
        self.label.setGeometry(QtCore.QRect(-10, -90, 1541, 270))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("UI_Designs\\banner.jpg"))
        self.label.setObjectName("label")
        
        self.grp_empInfo = QtWidgets.QGroupBox(self.scrollAreaWidgetContents)
        self.grp_empInfo.setGeometry(QtCore.QRect(30, 190, 1121, 371))
        
        font = QtGui.QFont()
        font.setFamily("Palatino Linotype")
        font.setPointSize(20)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        
        self.grp_empInfo.setFont(font)
        self.grp_empInfo.setStyleSheet("")
        self.grp_empInfo.setFlat(False)
        self.grp_empInfo.setCheckable(False)
        self.grp_empInfo.setObjectName("grp_empInfo")
        
        self.lbl_name_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_name_2.setGeometry(QtCore.QRect(40, 60, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_name_2.setFont(font)
        self.lbl_name_2.setObjectName("lbl_name_2")
        self.lbl_PhoNum_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_PhoNum_2.setGeometry(QtCore.QRect(40, 100, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_PhoNum_2.setFont(font)
        self.lbl_PhoNum_2.setObjectName("lbl_PhoNum_2")
        self.lbl_sex_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_sex_2.setGeometry(QtCore.QRect(40, 150, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_sex_2.setFont(font)
        self.lbl_sex_2.setObjectName("lbl_sex_2")
        self.lbl_MariStat_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_MariStat_2.setGeometry(QtCore.QRect(40, 190, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_MariStat_2.setFont(font)
        self.lbl_MariStat_2.setObjectName("lbl_MariStat_2")
        self.lbl_address_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_address_2.setGeometry(QtCore.QRect(40, 240, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_address_2.setFont(font)
        self.lbl_address_2.setObjectName("lbl_address_2")
        self.lbl_DOB_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_DOB_2.setGeometry(QtCore.QRect(40, 310, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_DOB_2.setFont(font)
        self.lbl_DOB_2.setObjectName("lbl_DOB_2")
        self.txt_name = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_name.setGeometry(QtCore.QRect(190, 60, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_name.setFont(font)
        self.txt_name.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.txt_name.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_name.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_name.setObjectName("txt_name")
        self.txt_phone = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_phone.setGeometry(QtCore.QRect(190, 100, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_phone.setFont(font)
        self.txt_phone.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_phone.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_phone.setObjectName("txt_phone")
        
        
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.radio_male = QtWidgets.QRadioButton(self.grp_empInfo)
        self.radio_male.setGeometry(QtCore.QRect(190, 150, 71, 21))
        self.radio_male.setFont(font)
        self.radio_male.setObjectName("radio_male")
        
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.radio_female = QtWidgets.QRadioButton(self.grp_empInfo)
        self.radio_female.setGeometry(QtCore.QRect(290, 150, 111, 21))
        self.radio_female.setFont(font)
        self.radio_female.setObjectName("radio_female")
        
        self.rdo_sex = QButtonGroup()

        # Add the radio buttons to the button group
        self.rdo_sex.addButton(self.radio_male)
        self.rdo_sex.addButton(self.radio_female)
        
        self.txt_add = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_add.setGeometry(QtCore.QRect(190, 230, 331, 61))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_add.setFont(font)
        self.txt_add.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.txt_add.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_add.setObjectName("txt_add")
        self.date_DOB = QtWidgets.QDateEdit(self.grp_empInfo)
        self.date_DOB.setGeometry(QtCore.QRect(190, 310, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.date_DOB.setFont(font)
        self.date_DOB.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.date_DOB.setCurrentSection(QtWidgets.QDateTimeEdit.MonthSection)
        self.date_DOB.setCalendarPopup(True)
        self.date_DOB.setCurrentSectionIndex(0)
        self.date_DOB.setDate(QtCore.QDate(2023, 5, 22))
        self.date_DOB.setObjectName("date_DOB")
        self.lbl_empID_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_empID_2.setGeometry(QtCore.QRect(590, 60, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_empID_2.setFont(font)
        self.lbl_empID_2.setObjectName("lbl_empID_2")
        self.lbl_email_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_email_2.setGeometry(QtCore.QRect(590, 110, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_email_2.setFont(font)
        self.lbl_email_2.setObjectName("lbl_email_2")
        self.lbl_dept_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_dept_2.setGeometry(QtCore.QRect(590, 160, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_dept_2.setFont(font)
        self.lbl_dept_2.setObjectName("lbl_dept_2")
        self.lbl_designation_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_designation_2.setGeometry(QtCore.QRect(590, 210, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_designation_2.setFont(font)
        self.lbl_designation_2.setObjectName("lbl_designation_2")
        self.lbl_StartDate_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_StartDate_2.setGeometry(QtCore.QRect(590, 260, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_StartDate_2.setFont(font)
        self.lbl_StartDate_2.setObjectName("lbl_StartDate_2")
        self.lbl_salary_2 = QtWidgets.QLabel(self.grp_empInfo)
        self.lbl_salary_2.setGeometry(QtCore.QRect(590, 310, 161, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.lbl_salary_2.setFont(font)
        self.lbl_salary_2.setObjectName("lbl_salary_2")
        self.txt_empID = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_empID.setGeometry(QtCore.QRect(740, 60, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_empID.setFont(font)
        self.txt_empID.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_empID.setObjectName("txt_empID")
        self.txt_email = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_email.setGeometry(QtCore.QRect(740, 110, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_email.setFont(font)
        self.txt_email.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_email.setObjectName("txt_email")
        self.txt_dept = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_dept.setGeometry(QtCore.QRect(740, 160, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_dept.setFont(font)
        self.txt_dept.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_dept.setObjectName("txt_dept")
        self.txt_designation = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_designation.setGeometry(QtCore.QRect(740, 210, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_designation.setFont(font)
        self.txt_designation.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_designation.setObjectName("txt_designation")
        self.txt_Salary = QtWidgets.QTextEdit(self.grp_empInfo)
        self.txt_Salary.setGeometry(QtCore.QRect(740, 310, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.txt_Salary.setFont(font)
        self.txt_Salary.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.txt_Salary.setObjectName("txt_Salary")
        self.date_DateStart = QtWidgets.QDateEdit(self.grp_empInfo)
        self.date_DateStart.setGeometry(QtCore.QRect(740, 260, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.date_DateStart.setFont(font)
        self.date_DateStart.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.date_DateStart.setCorrectionMode(QtWidgets.QAbstractSpinBox.CorrectToNearestValue)
        self.date_DateStart.setCalendarPopup(True)
        self.date_DateStart.setDate(QtCore.QDate(2023, 5, 22))
        self.date_DateStart.setObjectName("date_DateStart")
        self.cmb_mariStat = QtWidgets.QComboBox(self.grp_empInfo)
        self.cmb_mariStat.setGeometry(QtCore.QRect(190, 190, 331, 31))
        
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.cmb_mariStat.setFont(font)
        self.cmb_mariStat.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.cmb_mariStat.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.cmb_mariStat.setObjectName("cmb_mariStat")
        self.bttn_save = QtWidgets.QPushButton(self.scrollAreaWidgetContents)
        self.bttn_save.setGeometry(QtCore.QRect(1190, 260, 301, 50))
        
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        self.bttn_save.setFont(font)
        self.bttn_save.setStyleSheet("QPushButton {\n"
                                        "    background-color: rgb(45, 128, 145);\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover {\n"
                                        "    color: rgb(0, 0, 0);\n"
                                        "    background-color: rgb(200, 213, 203);\n"
                                        "}")
        self.bttn_save.setObjectName("bttn_save")
        self.bttn_update = QtWidgets.QPushButton(self.scrollAreaWidgetContents)
        self.bttn_update.setGeometry(QtCore.QRect(1190, 320, 301, 50))
        
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        self.bttn_update.setFont(font)
        self.bttn_update.setStyleSheet("QPushButton {\n"
                                        "    background-color: rgb(45, 128, 145);\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover {\n"
                                        "    color: rgb(0, 0, 0);\n"
                                        "    background-color: rgb(200, 213, 203);\n"
                                        "}")
        self.bttn_update.setObjectName("bttn_update")
        
        
        self.bttn_reset = QtWidgets.QPushButton(self.scrollAreaWidgetContents)
        self.bttn_reset.setGeometry(QtCore.QRect(1190, 380, 301, 50))
        
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        self.bttn_reset.setFont(font)
        self.bttn_reset.setStyleSheet("QPushButton {\n"
                                        "    background-color: rgb(45, 128, 145);\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover {\n"
                                        "    color: rgb(0, 0, 0);\n"
                                        "    background-color: rgb(200, 213, 203);\n"
                                        "}")
        self.bttn_reset.setObjectName("bttn_reset")
        
        
        self.bttn_delete = QtWidgets.QPushButton(self.scrollAreaWidgetContents)
        self.bttn_delete.setGeometry(QtCore.QRect(1190, 440, 301, 50))
        
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        self.bttn_delete.setFont(font)
        self.bttn_delete.setStyleSheet("QPushButton {\n"
                                        "    background-color: rgb(45, 128, 145);\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover {\n"
                                        "    color: rgb(0, 0, 0);\n"
                                        "    background-color: rgb(200, 213, 203);\n"
                                        "}")
        self.bttn_delete.setObjectName("bttn_delete")
        self.bttn_exit = QtWidgets.QPushButton(self.scrollAreaWidgetContents)
        self.bttn_exit.setGeometry(QtCore.QRect(1190, 500, 301, 50))
        
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        self.bttn_exit.setFont(font)
        self.bttn_exit.setStyleSheet("QPushButton {\n"
                                    "    background-color: rgb(45, 128, 145);\n"
                                    "    color: rgb(255, 255, 255);\n"
                                    "}\n"
                                    "\n"
                                    "QPushButton:hover {\n"
                                    "    color: rgb(0, 0, 0);\n"
                                    "    background-color: rgb(200, 213, 203);\n"
                                    "}")
        self.bttn_exit.setObjectName("bttn_exit")
        
        
        
        # Add search components
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        
        self.search_lineEdit = QLineEdit(self.scrollAreaWidgetContents)
        self.search_lineEdit.setGeometry(QtCore.QRect(30, 560, 200, 31))
        self.search_lineEdit.setFont(font)
        
        self.search_lineEdit.setStyleSheet("QLineEdit { font-size; }")
    
        font = QtGui.QFont()
        font.setFamily("Trebuchet MS")
        font.setPointSize(17)
        font.setBold(True)
        font.setWeight(75)
        
        
        self.search_button = QPushButton(self.scrollAreaWidgetContents)
        self.search_button.setGeometry(QtCore.QRect(240, 560, 80, 31))
        self.search_button.setText("Search")
        self.search_button.setFont(font)
        self.search_button.setStyleSheet("QPushButton {\n"
                                        "    background-color: rgb(45, 128, 145);\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover {\n"
                                        "    color: rgb(0, 0, 0);\n"
                                        "    background-color: rgb(200, 213, 203);\n"
                                        "}")
        self.tbl_empInfo()
        
        
        
        SystemWindow.setCentralWidget(self.scrollAreaWidgetContents)
        self.statusbar = QtWidgets.QStatusBar(SystemWindow)
        self.statusbar.setObjectName("statusbar")
        SystemWindow.setStatusBar(self.statusbar)

        self.retranslateUi(SystemWindow)
        QtCore.QMetaObject.connectSlotsByName(SystemWindow)


    def retranslateUi(self, SystemWindow):
        _translate = QtCore.QCoreApplication.translate
        SystemWindow.setWindowTitle(_translate("SystemWindow", "Main Window"))
        self.grp_empInfo.setTitle(_translate("SystemWindow", "Employee Information"))
        self.lbl_name_2.setText(_translate("SystemWindow", "Name:"))
        self.lbl_PhoNum_2.setText(_translate("SystemWindow", "Phone No.:"))
        self.lbl_sex_2.setText(_translate("SystemWindow", "Sex:"))
        self.lbl_MariStat_2.setText(_translate("SystemWindow", "Marital Status:"))
        self.lbl_address_2.setText(_translate("SystemWindow", "Address:"))
        self.lbl_DOB_2.setText(_translate("SystemWindow", "Date of Birth:"))
        self.radio_male.setText(_translate("SystemWindow", "Male"))
        self.radio_female.setText(_translate("SystemWindow", "Female"))
        self.date_DOB.setDisplayFormat(_translate("SystemWindow", "MM/dd/yyyy"))
        self.lbl_empID_2.setText(_translate("SystemWindow", "Employee ID:"))
        self.lbl_email_2.setText(_translate("SystemWindow", "Email:"))
        self.lbl_dept_2.setText(_translate("SystemWindow", "Department:"))
        self.lbl_designation_2.setText(_translate("SystemWindow", "Designation:"))
        self.lbl_StartDate_2.setText(_translate("SystemWindow", "Date Started:"))
        self.lbl_salary_2.setText(_translate("SystemWindow", "Salary"))
        self.date_DateStart.setDisplayFormat(_translate("SystemWindow", "MM/dd/yyyy"))
        self.bttn_save.setText(_translate("SystemWindow", "Save"))
        self.bttn_update.setText(_translate("SystemWindow", "Update"))
        self.bttn_reset.setText(_translate("SystemWindow", "Reset"))
        self.bttn_delete.setText(_translate("SystemWindow", "Delete"))
        self.bttn_exit.setText(_translate("SystemWindow", "Sign-Out"))


    def search_table(self):
        query = self.search_lineEdit.text().lower()
       
            
        # Iterate over the rows of the table and hide the rows that do not match the query
        for row in range(self.tableWidget.rowCount()):
            for column in range(self.tableWidget.columnCount()):
                item = self.tableWidget.item(row, column)
                if item and query in item.text().lower():
                    self.tableWidget.setRowHidden(row, False)
                    break
                else:
                    self.tableWidget.setRowHidden(row, True)

    def resetFields(self):
        # clear all fields
        self.txt_empID.clear()
        self.txt_name.clear() 
        self.txt_phone.clear() 

        self.radio_male.setChecked(False)
        self.radio_female.setChecked(False)
        
        self.cmb_mariStat.setCurrentIndex(0)
        self.txt_add.clear()
        self.date_DOB.setDateTime(QDateTime.currentDateTime())
        
        self.txt_email.clear()
        self.txt_dept.clear() 
        self.txt_designation.clear()
        self.date_DateStart.setDateTime(QDateTime.currentDateTime())
        self.txt_Salary.clear()
        self.statEmID=0
        self.load_data()


    def tbl_empInfo(self):
        self.scrollArea = QScrollArea(self.scrollAreaWidgetContents)
        self.scrollArea.setGeometry(QtCore.QRect(30, 600, 1471, 80))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        
        self.tableWidget = QTableWidget()
        self.scrollArea.setWidget(self.tableWidget)
        self.tableWidget.setObjectName("tableWidget")
        
        self.load_data()
        self.tableWidget.itemClicked.connect(self.handle_row_selection)
    
    def load_data(self):
        self.conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
        self.cur = self.conn.cursor()
        self.query = "SELECT * FROM tbl_empInfo"
        self.cur.execute(self.query)
        self.result = self.cur.fetchall()
        self.conn.close()
        
        self.tableWidget.setColumnCount(len(self.result[0]))
        self.tableWidget.setRowCount(len(self.result))
        
        headers = [description[0] for description in self.cur.description]
        self.tableWidget.setHorizontalHeaderLabels(headers)
        
        for i, row in enumerate(self.result):
            for j, val in enumerate(row):
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)  # Make cell non-editable
                self.tableWidget.setItem(i, j, item)
    
    def handle_row_selection(self, item):
        selected_row = item.row()
    
        # Select all columns in the selected row
        for j in range(self.tableWidget.columnCount()):
            self.tableWidget.item(selected_row, j).setSelected(True)
        
        # Retrieve the empID from the selected row
        emp_id = self.tableWidget.item(selected_row, 0).text()
        
        # Perform your desired action here, using the empID
        self.setEmpInfo(emp_id)


    


    def setEmpInfo(self, empID):
        try:
            conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
            cur=conn.cursor()
            query = "SELECT * FROM tbl_empInfo WHERE empID = %s"
            values = (empID,)
            cur.execute(query, values)
            conn.close()
            result= cur.fetchone()
            # Fetch the result
            if result:
                self.txt_empID.setText(str(result[0]))
                self.txt_name.setText(str(result[1]))
                self.txt_phone.setText(str(result[2]))
                if(str(result[3])=="Male"):
                    self.radio_male.setChecked(True)
                else:
                    self.radio_female.setChecked(True)
                self.cmb_mariStat.setCurrentText(str(result[4]))
                self.txt_add.setText(str(result[5]))
                self.date_DOB.setDate(result[6])
                
                self.txt_email.setText(str(result[7]))
                self.txt_dept.setText(str(result[8]))
                self.txt_designation.setText(str(result[9]))
                self.date_DateStart.setDate(result[10])
                self.txt_Salary.setText(str(result[11]))
                self.statEmID=result[0]
                
        
        except mdb.Error as e:
            QMessageBox.information(None, "Notification", "There's an error executing sql statement!")
            return 0

    def emptyField(self):
        if(self.rdo_sex.checkedButton() is None
           or self.cmb_mariStat.currentIndex() == -1 
           or self.txt_empID.toPlainText()=="" 
           or self.txt_name.toPlainText()=="" 
           or self.txt_phone.toPlainText()=="" 
           or self.txt_add.toPlainText()=="" 
           or self.txt_email.toPlainText()=="" 
           or self.txt_dept.toPlainText()=="" 
           or self.txt_designation.toPlainText()=="" 
           or self.txt_Salary.toPlainText()==""):
            return True
        else:
            return False

    def empExists(self):
        try:
            conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
            cur=conn.cursor()
            query = "SELECT * FROM tbl_empInfo WHERE EmpID = %s AND EmpID <> %s"  # Update the query
            values = (self.txt_empID.toPlainText(), self.statEmID)  # Set the value to exclude
    
            cur.execute(query, values)
            conn.close()
            
            return cur.fetchone() is not None
        
        except mdb.Error as e:
            QMessageBox.information(None, "Notification", "empExists sql query failed")
            
    
    def updateEmpInfo(self):    
        if(self.emptyField()):
            QMessageBox.information(None, "Notification", "Please input all fields!")
        elif(self.empExists()):
              QMessageBox.information(None, "Notification", "Employee ID already exists! Please login to your original account.")
              self.txt_empID.setText(str(self.statEmID))
        elif(self.statEmID==0):
            self.insertEmpInfo()
        else:
            try:
                conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
                cur=conn.cursor()
            	
                query = "UPDATE tbl_empInfo SET EmpID = %s, Name= %s, PhoneNumber= %s, Sex= %s, MaritalStatus= %s, Address= %s, DateOfBirth= %s, Email= %s, Department= %s, Designation= %s, DateStarted= %s, Salary= %s WHERE EmpID = %s"
                values = (
                    self.txt_empID.toPlainText(), 
                    self.txt_name.toPlainText(), 
                    self.txt_phone.toPlainText(), 
                    self.rdo_sex.checkedButton().text(), 
                    self.cmb_mariStat.currentText(), 
                    self.txt_add.toPlainText(), 
                    self.date_DOB.date().toString("yyyy-MM-dd"), 
                    self.txt_email.toPlainText(), 
                    self.txt_dept.toPlainText(), 
                    self.txt_designation.toPlainText(), 
                    self.date_DateStart.date().toString("yyyy-MM-dd"), 
                    self.txt_Salary.toPlainText(), 
                    self.statEmID)
                cur.execute(query, values)
                conn.commit()
                conn.close()
                
                self.statEmID=self.txt_empID.toPlainText()
                QMessageBox.information(None, "Notification", "Your employee info is successfully updated!")
                
            
            except mdb.Error as e:
                QMessageBox.information(None, "Notification", "There'mmms an error executing sql statement!")
            self.load_data()

    def insertEmpInfo(self):
        if(self.emptyField()):
            QMessageBox.information(None, "Notification", "Please input all fields!")
        elif(self.empExists()):
              QMessageBox.information(None, "Notification", "Employee ID already exists! Please login to your original account.")
        elif(self.statEmID!=0):
            self.updateEmpInfo()
            
            
        else:
            try:
                conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
                cur=conn.cursor()
            	
                query = "INSERT INTO tbl_empInfo (EmpID, Name, PhoneNumber, Sex, MaritalStatus, Address, DateOfBirth, Email, Department, Designation, DateStarted, Salary) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                values = (self.txt_empID.toPlainText(), self.txt_name.toPlainText(), self.txt_phone.toPlainText(), self.rdo_sex.checkedButton().text(), self.cmb_mariStat.currentText(), self.txt_add.toPlainText(), self.date_DOB.date().toString("yyyy-MM-dd"), self.txt_email.toPlainText(), self.txt_dept.toPlainText(), self.txt_designation.toPlainText(), self.date_DateStart.date().toString("yyyy-MM-dd"), self.txt_Salary.toPlainText())
                cur.execute(query, values)
                conn.commit()
                conn.close()
                self.statEmID=self.txt_empID.toPlainText()
                QMessageBox.information(None, "Notification", "Your employee info is saved!")
                
            
            except mdb.Error as e:
                QMessageBox.information(None, "Notification", "There's an error executing sql statement!")
           
        self.load_data()
    def deleteEmpInfo(self):
        # Process the user's response
        if QMessageBox.question(None, "Confirmation", "Are you sure you want to delete this employee info?", QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            
            try:
                conn = mdb.connect("localhost", "root", "", "jape_solutions_db")
                cur=conn.cursor()
            	
                query = "DELETE FROM tbl_empInfo WHERE EmpID = %s"
                values = (self.statEmID,)
                cur.execute(query, values)
                conn.commit()
                conn.close()
                self.statEmID=self.txt_empID.toPlainText()
                QMessageBox.information(None, "Notification", "Your employee info is deleted!")
                
            
            except mdb.Error as e:
                QMessageBox.information(None, "Notification", "There's an error executing sql statement!")
            
            
            self.resetFields()